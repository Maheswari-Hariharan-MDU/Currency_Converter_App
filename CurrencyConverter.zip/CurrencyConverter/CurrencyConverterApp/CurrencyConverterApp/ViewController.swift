//
//  ViewController.swift
//  CurrencyConverterApp
//
//  Created by Maheswari on 17/06/23.
//

import UIKit
import Foundation
import GoogleSignIn
import GoogleUtilities

let config = GIDConfiguration(clientID: "698304245668-qc4gd9ecmnp1q091urhbnmi600spk15a.apps.googleusercontent.com")

class ViewController: UIViewController{
    
    
    @IBAction func GoogleSignInTapped(_ sender: Any) {
        
        GIDSignIn.sharedInstance.signIn(with: config, presenting: self){[unowned self] result, error in
            if let errorMessage = error{
                print(errorMessage.localizedDescription)
            }
            else{
                moveToNextPage()
                
            }
            
        }
        
        
    }
    func moveToNextPage(){
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ConverterViewController") as! ConverterViewController
        self.present(vc, animated: true, completion: nil)
        
    }
    
    @IBOutlet weak var googleButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    
}

