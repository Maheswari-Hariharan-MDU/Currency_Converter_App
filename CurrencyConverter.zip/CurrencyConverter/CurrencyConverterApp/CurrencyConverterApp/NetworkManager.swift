//
//  NetworkManager.swift
//  CurrencyConverterApp
//
//  Created by Maheswari on 17/06/23.
//

import Foundation

let urlString = "http://api.exchangeratesapi.io/v1/latest?access_key=a00e38904673a306195a8cec5eb29cc3&format=1"


struct Currency : Codable{
    let success: Bool
    let timestamp: Int
    let base, date: String
    let rates: [String: Double]
}

class NetworkManager: NSObject {
    static let shared = NetworkManager()
    
    private override init() {}

    class func getData(urlString : String,completionHandler: @escaping (Any) -> ()) {

            guard let url = URL(string: urlString) else {
                print("Url conversion issue.")
                return
            }

            var request = URLRequest(url: url)

            request.httpMethod = "GET"

            URLSession.shared.dataTask(with: request, completionHandler: { (data, response, error) -> Void in
                if error == nil && data != nil {
                    do {
                       
                        let rates = try JSONDecoder()
                            .decode(Currency.self,
                                    from: data!)

                        completionHandler(rates)

                    } catch {
                        completionHandler(false)
                    }
                }
                else if error != nil
                {
                    completionHandler(false)
                }
            }).resume()
        }
  
}
