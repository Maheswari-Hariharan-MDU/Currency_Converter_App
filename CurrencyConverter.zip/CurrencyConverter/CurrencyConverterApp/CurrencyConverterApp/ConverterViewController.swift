//
//  ConverterViewController.swift
//  CurrencyConverterApp
//
//  Created by Maheswari on 17/06/23.
//

import Foundation
import UIKit
import DropDown
import GoogleSignIn

class ConverterViewController: UIViewController,UITextFieldDelegate{
    @IBOutlet weak var homeView: UIView!
    var ratess : Currency?
    @IBOutlet weak var homeCurrencyView: UIView!


    @IBOutlet weak var toValue: UITextField!
    @IBOutlet weak var fromValue: UITextField!
    @IBOutlet weak var toButton: UIButton!
    @IBOutlet weak var homeButton: UIButton!
    var currentField: UITextField = UITextField()
    
    
    override func viewDidLoad() {
        NetworkManager.getData(urlString: urlString,completionHandler: { respnse in
            print(respnse)
            self.ratess = respnse as? Currency
            
        })
        self.fromValue.delegate = self
        self.toValue.delegate = self

        super.viewDidLoad()
    }
    func showDropDown(isHome: Bool){
        let values = [String] (ratess?.rates.keys ?? ["":0.0].keys )
        let dropDown = DropDown()
        dropDown.anchorView = homeCurrencyView
        dropDown.dataSource = values
        dropDown.selectionAction = {(index: Int, item: String) in
            self.dropDownSelected(isHome: isHome, index: index, item: item)
        }
        dropDown.width = 200
        dropDown.show()
    }
    func dropDownSelected(isHome: Bool, index: Int, item: String){
        if(isHome){
            self.homeButton.setTitle(item, for: .normal)
        }
        else{
            self.toButton.setTitle(item, for: .normal)

        }
    }
    @IBAction func homeBtnTapped(_ sender: Any) {
        
    showDropDown(isHome: true)
    }
    @IBAction func toBtnTapped(_ sender: Any) {
        
    showDropDown(isHome: false)
    }
    
    @IBAction func logoutButtonAction(_ sender: Any) {
        GIDSignIn.sharedInstance.signOut()
        self.dismiss(animated: true)
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        self.currentField = textField
        return true
    }
    @IBAction func convertTapped(_ sender: Any) {
        var fromMoney = homeButton.titleLabel?.text ?? ""
        var toMoney = toButton.titleLabel?.text ?? ""

        if(currentField == toValue){
             fromMoney = toButton.titleLabel?.text ?? ""
             toMoney = homeButton.titleLabel?.text ?? ""

        }
        var euroValue  = 0.0
        
        if let value  = currentField.text{
            
            guard let euro =  (ratess?.rates[fromMoney]) else{
                return
            }
             euroValue  = ((Double(value) ?? 1) / euro)

                guard let val =  (ratess?.rates[toMoney]) else{
                    return
                }
            euroValue = (euroValue * val)
 
        }
        if(currentField == toValue){
            fromValue.text = euroValue.description
        }
        else{
            toValue.text = euroValue.description

        }
        
    }
    
}
